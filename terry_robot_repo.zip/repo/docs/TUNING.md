# Tuning Guide

All tunables live at the top of `firmware/real_esp32_terry.ino`. Several
interact; the interactions are the part that isn't obvious from the source.

## Output shaping

| Constant | Current | Effect |
|---|---|---|
| `DUTY_MAX` | `0.5f` | Duty at full command. Comments in the file describe 0.75 (30 µs high / 10 µs low); 0.5 is a deliberate experimental setting, not a bug. At 0.5 the >50 %-duty branch of the encoder is unreachable. Raise toward 0.75 for more top-end. |
| `MIN_SPEED_OUTPUT` | `0.55f` | Output floor: any nonzero command maps into [0.55, 1.0] before the duty multiply. Calibrates around the motors' physical dead zone (no response below ~0.5 command). Consequence: output *steps* from 0 to ~`DUTY_MAX×0.55` at the deadband; expect that on the scope. |
| `SPEED_DEADBAND` | `0.01f` | Below this |cmd| the output is constant low. Also the threshold the trim clamp protects (trim may not push a command across zero). |
| `PULSE_US` | `10.0f` | The latched minority-phase width. Sets the frequency scale (50 kHz peak at 50 % duty). Motor-driver dependent; changing it changes every frequency in PROTOCOLS.md §3. |
| `LEDC_RES` | `10` bits | Duty resolution. At the frequencies in use the divider lands near-exact, so 10 µs is accurate; off-round settings will quantize slightly. |

## Input curves and mix (RC path only)

Throttle and steer both pass through a **cubic** (`n³`): soft around center,
full authority at the stick ends. Steer is additionally scaled by `0.8`,
which caps how hard steering can differentiate the sides. History note: cube
*root* was tried first and made steering hyper-sensitive at center (inside
wheel driven through zero at a feather of stick) — see DECISION_LOG entry 5.
If steering feels too soft near center, reduce the cubic toward linear
(e.g. blend `0.5·n + 0.5·n³`) rather than reaching for `cbrt`.

The arcade mix (`left = t + s`, `right = t − s`) can exceed ±1 on diagonals;
the normalizer divides both sides by the max, preserving turn ratio. A
subtractive-steering variant (outside wheel pinned at throttle, inside wheel
slowed, full straight-line speed, no spin-in-place) was designed and is in
the conversation history but was **not** adopted; the additive mix above is
what ships.

## Trim (left/right imbalance)

Physical symptom being corrected: constant imbalance across the speed range —
left runs hot going forward, right runs hot in reverse (antisymmetric).

Current implementation (owner's, one-sided):

```c
if (left  < 0) lt = left  + TRIML;   // boost left magnitude... only when reversing
if (right > 0) rt = right - TRIMR;   // shave right magnitude... only when forward
```

`TRIML = 0.03`, `TRIMR = 0.01`, tuned experimentally. Two facts to keep in
mind when re-tuning: (a) the `MIN_SPEED_OUTPUT` remap compresses command
deltas roughly 2:1 on the way to duty, so effective output change is about
half the constant you set; (b) the sign-flip clamp after the trim zeroes any
command the trim pushes across zero — that clamp is what keeps a trim
constant from reversing a nearly-stopped motor and flipping its DIR pin.
Do not remove it.

A symmetric two-line version (`left -= TRIM; right += TRIM;` unconditional,
correcting both directions via the fabsf in `writeMotor`) is documented in
DECISION_LOG entry 4 if the one-sided form ever proves insufficient.

## Timing / safety

| Constant | Current | Effect |
|---|---|---|
| `SIGNAL_TIMEOUT` | 100 ms | SBUS silence before RC is "gone" and autonomy is permitted. Shorter = faster failover, more sensitive to RF dropouts. |
| `CMD_TIMEOUT` | 200 ms | Host silence before autonomous stop. Host senders must stream faster than this (both host tools do: 50 Hz Jetson, 20 Hz Windows). Widening it weakens the dead-man behavior. |
| `TXOFF_FLAG` | `0x10` | Flag-byte bit meaning "TX off". **Unverified** — OPEN_ISSUES §1. |
| `FRAME_GAP_US` | 3000 µs | SBUS inter-byte gap that resets frame alignment. |

## Host-side (`host/esp32_drive.py`)

`track_width` (default 0.30 m) and `v_max` (default 1.0) are placeholders —
set them to the real robot geometry or `set_twist` turn rates will be wrong.
They do not affect `set_wheels`. `send_hz` (50) and the teleop `STEP` (0.05
per keypress) are taste; keep `send_hz` well above `1000/CMD_TIMEOUT`.
