# Wire Protocols

Three distinct electrical interfaces. They use different UART configurations —
do not carry settings from one to another when probing or configuring tools.

## 1. SBUS input (RC receiver → ESP32 GPIO16)

| Property | Value |
|---|---|
| Baud | 100000 |
| Frame format | **8E2** (8 data, even parity, 2 stop) |
| Polarity | **Inverted** (handled by the ESP32 UART's invert flag, no external inverter) |
| Bit order | LSB first |
| Level | 3.3 V |

Packet: 25 bytes. `buf[0] = 0x0F` header, `buf[1..22]` = 16 channels packed
11 bits each LSB-first, `buf[23]` = flag byte, `buf[24] = 0x00` footer.

Channels in use: `ch0` = steer, `ch1` = throttle; calibration
600 = full left/reverse, 1000 = center, 1400 = full right/forward
(`DRIVE_MIN/MID/MAX`).

Flag byte (`buf[23]`) bits, standard SBUS: `0x04` frame lost, `0x08`
failsafe. **This project additionally treats `0x10` as "transmitter off"**
(tested as a bitmask). That value came from the owner's observation and has
not been verified on the analyzer — see OPEN_ISSUES §1.

Framing recovery: a >3 ms inter-byte gap (`FRAME_GAP_US`) resets the parser;
frames are accepted only with valid header **and** a strict `0x00` footer.
Some receiver variants send a non-zero end byte and would be rejected
entirely (permanent failsafe) — if a new receiver "doesn't work," check this
first.

## 2. Host command link (Jetson/laptop → ESP32 USB)

| Property | Value |
|---|---|
| Transport | USB → onboard CP2102 → UART0 (`Serial`) |
| Baud | 115200 |
| Frame format | **8N1**, LSB first, **non-inverted** (idle high) |
| Level | 3.3 V TTL on the UART side of the bridge |

Application layer — newline-terminated printable ASCII, one command per line:

| Line | Meaning |
|---|---|
| `M <left> <right>\n` | Set wheel speeds, each −1..+1 (e.g. `M 0.500 -0.250`). `\r` also accepted as terminator. A bare `<left> <right>` without the `M` is also parsed. |
| `S\n` | Stop (sets both to 0). |

Semantics: values are clamped to ±1; malformed lines are silently dropped
(the 32-byte line buffer resets on overflow). **Every valid line is a
heartbeat** — `CMD_TIMEOUT` (200 ms) without one stops the robot when the
host is the active source. Hosts should stream at 20–50 Hz. The link is
currently one-way; nothing is transmitted back.

Human test: open the COM port in any serial terminal at 115200 8N1 and type
`M 0.3 0.3` + Enter. If that drives but a script doesn't, the problem is the
port/arbitration, not the wiring.

## 3. Motor outputs (ESP32 → drivers)

Per side: one **speed** pin (PFM) and one **direction** pin, both 3.3 V.

**Direction** (GPIO33 left, GPIO32 right): plain logic level. HIGH = that
side spins forward, LOW = reverse. Also LOW when stopped and on failsafe.
Updated before the speed write, from the sign of the post-trim command.

**Speed** (GPIO25 left, GPIO26 right): magnitude-only pulse train where the
minority phase is latched at 10 µs and frequency encodes the rest:

| \|cmd\| | duty | waveform | frequency |
|---|---|---|---|
| < 0.01 | 0 % | constant low | — |
| 0.01 (deadband edge) | 27.5 % | 10 µs high / ~26.4 µs low | ~27.5 kHz |
| 0.05 | 28.6 % | 10 µs high / ~25 µs low | ~28.6 kHz |
| 0.50 | 38.75 % | 10 µs high / ~15.8 µs low | ~38.8 kHz |
| 1.00 | 50 % | 10 µs / 10 µs square | 50 kHz |

Note the step at the deadband: output jumps from 0 to ~27.5 % duty
(the `MIN_SPEED_OUTPUT` floor). Duty does **not** scale linearly from zero,
and the >50 %-duty regime is unreachable at the current `DUTY_MAX = 0.5`.
Small (±1 LEDC tick) period wobble on the low phase is normal — fractional
divider dither at 10-bit resolution — and harmless.

## Logic analyzer settings

Common ground with the ESP32 is mandatory. ≥1 MS/s for the UARTs, a few MS/s
for the PFM outputs. Trigger on a falling edge (start bit / pulse start).

| Probing | Decoder config |
|---|---|
| SBUS (GPIO16) | UART, 100000 baud, 8E2, **inverted** |
| Host link (USB side inaccessible; probe the CP2102↔ESP32 traces or use a terminal instead) | UART, 115200, 8N1, non-inverted |
| Speed pins (25/26) | No decoder; measure pulse widths. Expect the table above. |

Scrambled-but-present bytes = wrong decoder settings (baud/parity/inversion).
Nothing at all = wrong line or missing ground.
