# Decision Log

Chronological record of the development session that produced this code.
Each entry: what was observed, what the cause was, what was decided. The
point of this file is to stop a future engineer from re-introducing a fixed
bug or "cleaning up" something that is deliberate.

## 1. `DUTY_MAX` disagrees with its own comments — deliberate

The header and inline comments describe 75 % max duty (30 µs high / 10 µs
low); the constant is `0.5f`. Flagged as a bug; owner confirmed it is
**meant to be adjusted experimentally**. Leave the mismatch; treat the
comments as describing the design intent at `0.75`.

## 2. "No proportional control at low speed" — retracted

`MIN_SPEED_OUTPUT` snaps any nonzero command to a high output floor, which
initially looked like a control-resolution defect. Owner clarified the motors
**physically do not respond below ~0.5 command**; the floor is a calibration
of the usable range, not a flaw. A startup-boost/taper mechanism designed on
the wrong assumption was discarded. Do not remove the floor.

## 3. Original trim conditionals were dead logic — fixed

The first trim implementation gated on raw channel sums
(`ch[1] + ch[0] > 0`), which are always ~1200–2800 and therefore always
true/meaningless: one side got a constant bias, direction never mattered.
Root cause of "trim didn't fix the imbalance."

## 4. Trim architecture: antisymmetric constant offset

The physical imbalance is antisymmetric (left hot forward, right hot
reverse). Because `writeMotor` acts on |command|, a plain constant offset in
signed-command space (`left −= TRIM; right += TRIM;`) corrects **both**
directions with two unconditional lines: subtracting from a positive command
shrinks magnitude, subtracting from a negative one grows it. Two supporting
pieces: (a) a **sign-flip clamp** — if trim pushes a command across zero,
zero it, or a near-stopped motor can be commanded backward (and its DIR pin
flipped); (b) place trim **after** the mix normalizer so the offset is
constant regardless of stick position. The owner later split this into
one-sided `TRIML`/`TRIMR` applied only in specific directions (current code);
the clamp and ordering survive and must be preserved.

Also fixed here: a copy-paste bug where the right-trim branch assigned `lt`
instead of `rt`, which — via the sign-flip clamp — zeroed the **left** motor
whenever the right side reversed ("only one side turns when pivoting").
Symptom to remember: a wrong-variable trim bug presents as a dead motor in
specific maneuvers, not as a subtle bias.

## 5. Steering curve: cube, not cube root

`cbrt(n)` was tried for a steering curve. Cube root has infinite slope at
zero, so a feather of stick produced a huge steer term that drove the inside
wheel through zero → "only one side turns when throttle > 0." The intended
soft-center behavior is the **cube** (`n³`). Current code uses n³ on both
axes, steer scaled 0.8.

## 6. Direction outputs

DIR pins (33 left, 32 right, HIGH = forward) are driven from the sign of the
**final post-trim** command, after the sign-flip clamp, so the pin can never
disagree with the speed output. `driveStop()` forces both LOW for a defined
failsafe state. GPIO 32/33 chosen deliberately: no boot-strapping roles.

## 7. LEDC waveform corruption ("two highs back to back")

Analyzer showed ~1 µs runt lows every other cycle at steady command. Cause:
once arbitration ran every loop iteration, `writeMotor` called
`ledcChangeFrequency` continuously; that call reloads the timer counter, and
a mid-period reload truncates the running cycle. Fix: per-pin change
detection (`lastFreq[]`/`lastDuty[]` static caches) — the peripheral is
touched only when a value changes; steady state performs zero writes.
`ledcWrite` alone latches at the period boundary (clean); it is
`ledcChangeFrequency` that must be rationed. Verified by simulation:
100 000 identical calls → exactly 1 peripheral write.

## 8. Regression: output went fully dead after the cache — fixed

`driveStop()` still wrote `ledcWrite(pin, 0)` **directly**, bypassing the
cache. After any stop, the cache claimed the old frequency/duty were still
programmed, so re-sending the same command was a silent no-op → no output at
all. Fix: `driveStop()` routes through `writeMotor(pin, 0.0f)`. **Invariant
established: every speed-pin write goes through `writeMotor`.** Verified by
simulation of drive→stop→drive cycles.

## 9. Jetson integration: interface and transport choices

Decided the host sends **normalized left/right wheel speeds** (kinematics
stay host-side; the ESP32 is purely an actuator translator). Protocol is
newline-terminated ASCII (`M l r` / `S`) — human-typeable, terminal-
debuggable, every line doubles as a heartbeat with a 200 ms watchdog.
Originally on UART1 (GPIO 4/13, remapped off the flash bus); see entry 11.

## 10. Arbitration: mode switch → TX-presence

First design used an RC channel as an AUTO/MANUAL switch with RC as
dead-man. Owner replaced it with **transmitter-presence** arbitration:
autonomy allowed iff no SBUS frames OR flag byte has `0x10` set; a live TX is
always exclusive. Truth table verified by simulation (including: frame-lost
bit `0x04` alone stays RC). Convenient side effect: a bench with no TX
powers straight into host control. Known gaps: `0x10` unverified, no
handover debounce (OPEN_ISSUES §1–2).

## 11. Host link moved to the USB port (UART0)

Owner chose to use the ESP32's own USB (Elegoo board, CP2102 bridge — 
verified) instead of a USB-TTL adapter on UART1. Consequences accepted:
`Serial` is no longer a debug console (banner print removed; printing there
corrupts commands), and opening the port auto-resets the board via DTR/RTS
(~300 ms; host code sleeps 0.4 s after connect). UART1 is now free.

## 12. Host tooling

`drive_keyboard.py` (Windows, msvcrt): r/f/u/j teleop, streams at 20 Hz even
while idle to feed the watchdog, always sends `S` on exit.
`esp32_drive.py` (Jetson/Linux): `ESP32Drive` class with a 50 Hz daemon
sender decoupling the planner tick from the link cadence; `set_twist` does
differential kinematics (ratio preserved on saturation — verified);
run-directly mode is the same r/f/u/j teleop via termios cbreak.

## Superseded designs (in conversation history, not in code)

- Startup-boost trim with speed taper (entry 2's wrong assumption).
- Symmetric two-line trim (entry 4) — replaced by owner's one-sided version.
- Subtractive-steering mix (full straight-line speed, no spin-in-place) —
  designed, not adopted.
- Mode-switch arbitration + `USE_RC_OVERRIDE` flag (entry 10).
- UART1 GPIO host link (entry 11).
