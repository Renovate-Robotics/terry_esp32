# Open Issues & Unverified Assumptions

Ordered by risk. Items 1–2 gate safe field deployment.

## 1. `TXOFF_FLAG 0x10` is unverified  ⚠️ safety-relevant

Arbitration hands control to the host when SBUS frames arrive with bit 4
(0x10) set in the flag byte. That value came from the owner's report, not
from a captured trace. Standard SBUS defines `0x04` = frame lost and `0x08`
= failsafe; `0x10` is nonstandard. Risks if wrong: TX-off is never detected
(autonomy only ever engages via total frame loss — benign if the receiver
goes silent when the TX is off, which many do), or worse, the receiver sets
0x10 in some *other* condition and autonomy engages with the TX live.

**Action:** capture the flag byte on a logic analyzer (SBUS decoder settings
in PROTOCOLS.md) with the TX on, then off. Set `TXOFF_FLAG` to what is
actually observed, or delete the flag path entirely if the receiver simply
stops transmitting.

## 2. No arbitration debounce  ⚠️ safety-relevant

Handover both directions is instantaneous. A marginal RF link hovering at the
100 ms `SIGNAL_TIMEOUT` edge can bounce control between RC and host several
times a second (motors alternately obeying sticks and planner). Proposed but
not implemented: require RC to be continuously present ~100 ms before it
reclaims control. Also note: if the TX reappears mid-autonomous-maneuver, RC
seizes control that instant with whatever the stick positions are.

## 3. SBUS failsafe bit (`0x08`) is not checked

If the receiver keeps streaming frames with the failsafe bit set after losing
its TX link (common behavior), the firmware treats those as a live TX and
keeps RC in control with whatever failsafe channel values the receiver emits.
Checking `buf[23] & 0x08` (and `0x04`) would make link-loss handling robust.
Interacts with issue 1 — resolve them from the same analyzer capture.

## 4. Strict `0x00` footer check

Frames are rejected unless `buf[24] == 0x00`. Receiver variants that send a
non-zero end byte would be rejected wholesale (permanent failsafe). Only
matters if the receiver hardware changes.

## 5. Host link is one-way

No acknowledgements, no telemetry. The planner cannot observe which source is
active, battery state, or the post-trim applied wheel values. Discussed and
deferred. Natural transport: either structured lines back over USB, or the
freed UART1 (GPIO 4/13 — remap explicitly; UART1 default pins overlap the
flash bus).

## 6. Auto-reset on host connect

Opening the USB port asserts DTR/RTS and reboots the ESP32 (~300 ms dead
time, motors stopped). Acceptable on the bench; potentially disruptive if a
Jetson service restarts mid-mission. Possible mitigations: open with
`dtr=False`/`rts=False` (board-dependent whether this fully suppresses the
reset), or hardware-disable the auto-reset circuit.

## 7. Trim values are provisional

`TRIML = 0.03`, `TRIMR = 0.01` were being tuned experimentally when the
session ended, against the one-sided scheme described in TUNING.md. Re-verify
straight-line tracking in both directions after any change to `DUTY_MAX` or
`MIN_SPEED_OUTPUT`, since the output compression (≈2:1) scales the trim's
effect.

## 8. `DUTY_MAX` / top-speed headroom unresolved

At `DUTY_MAX = 0.5` the >50 %-duty output regime is dead code and top speed
is capped at a 50 % duty square wave. Owner is adjusting deliberately
(DECISION_LOG entry 1). Separately, full-forward stick reaches |cmd| = 1.0
only because the cubic curve maps stick extremes to ±1 — but a
throttle+steer diagonal still saturates the normalizer differently than pure
throttle; if straight-line top speed ever feels low relative to cornering,
revisit the subtractive-steering design in the decision log.

## 9. Minor firmware nits

`DRIVE_MIN` is defined but unused (calibration is centered on
`DRIVE_MID`/`DRIVE_MAX`). `writeMotor`'s cache arrays are indexed by GPIO
number with size 40 — fine for pins 25/26, but silently out-of-bounds if a
speed pin ≥ 40 is ever chosen. The Windows teleop and the firmware's
`INVERT_STEER` remain untested against the final merged firmware as a set —
a 10-minute bench pass (RC drive, TX off, keyboard drive, TX back on) would
close the loop.
