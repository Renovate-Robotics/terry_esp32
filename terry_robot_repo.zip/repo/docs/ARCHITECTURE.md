# Architecture

## Firmware structure (`firmware/real_esp32_terry.ino`)

The firmware is organized around one invariant: **two command sources, one
actuator path.** Everything that touches the motors funnels through a single
function so that trim, direction handling, and the PFM encoding behave
identically no matter who is driving.

```
loop()
 ├─ SBUS byte-framing ──► processFrame() ──► rcLeft/rcRight/rcFlags   (stored, not driven)
 ├─ pollHost()         ──► parseCommand() ──► jLeft/jRight, lastCmdMs (stored, not driven)
 └─ controlStep()      ──► arbitration ──► driveMotors(l, r)  or  driveStop()
                                              │
                                              ├─ antisymmetric L/R trim + sign-flip clamp
                                              ├─ DIR pins (sign of final command)
                                              └─ writeMotor() per side  (PFM encoding,
                                                 change-detected LEDC writes)
```

`processFrame` and `parseCommand` are pure ingestion: they decode and stash
the latest command plus a freshness timestamp. Neither drives the motors.
`controlStep` runs every loop iteration, decides the active source, and calls
the shared actuator path. This is why the change-detection in `writeMotor`
is load-bearing and not an optimization — see "The LEDC glitch" below.

## Signal chain, command → shaft

For the RC path: raw SBUS channel (600..1400) → `norm()` to −1..+1 →
**cubic input curve** (throttle = n³, steer = 0.8·n³) → arcade mix
(left = t+s, right = t−s) → ratio-preserving normalizer if |·|>1 →
stored as `rcLeft/rcRight`.

For the host path: the ASCII value is already a normalized wheel speed,
clamped to −1..+1 and stored as `jLeft/jRight`. No curve, no mix — the
planner is expected to have done its own kinematics
(`ESP32Drive.set_twist` does differential-drive math host-side).

Then, in `driveMotors`, for whichever pair won arbitration:

1. **Trim** (one-sided, per the observed physical imbalance): `+TRIML` added
   to left only when left is reversing; `−TRIMR` applied to right only when
   right runs forward. A sign-flip clamp zeroes any command the trim pushed
   across zero, so trim can never reverse a near-stopped motor (which would
   also flip its DIR pin).
2. **DIR pins** from the sign of the final, post-trim command
   (HIGH = forward). Placed after the clamp deliberately, so pin state can
   never disagree with the speed output.
3. **`writeMotor`** encodes |command| into the PFM signal (next section).

## The PFM output scheme

The speed signal is not fixed-frequency PWM. The **minority phase** (whichever
of high/low is shorter) is latched to `PULSE_US` = 10 µs, and frequency varies
to realize the requested duty:

```
duty  = DUTY_MAX × (MIN_SPEED_OUTPUT + (1 − MIN_SPEED_OUTPUT) × |cmd|)
minor = min(duty, 1 − duty)
freq  = minor / 10 µs
```

With the current constants (`DUTY_MAX 0.5`, `MIN_SPEED_OUTPUT 0.55`) the
output is: off below the 0.01 deadband, then a step to ~27.5 % duty, rising
to 50 % duty (10 µs/10 µs square at 50 kHz) at full command. Below 50 % duty
the waveform is a fixed 10 µs high pulse with a variable low gap.

`MIN_SPEED_OUTPUT` exists because **the motors physically do not respond to
commands below ~0.5** — it is a calibration mapping the usable command range
onto the motors' responsive range, not a stiction kick. Do not remove it to
"restore proportionality at low speed"; that was investigated and reversed
(DECISION_LOG entry 2).

`DUTY_MAX` is intentionally left at 0.5 even though header comments describe
0.75 behavior; the owner adjusts it experimentally (DECISION_LOG entry 1).

## The LEDC glitch and the write cache (critical)

`ledcChangeFrequency` reloads the LEDC timer counter. Calling it mid-period
truncates the running cycle, which showed up on the analyzer as ~1 µs runt
lows / back-to-back 10 µs highs on roughly every other cycle. Because
`controlStep` → `driveMotors` → `writeMotor` runs on **every loop iteration**
(necessary to service the host watchdog), an unguarded `writeMotor` hammers
the peripheral at hundreds of kHz and corrupts the waveform continuously.

Fix: `writeMotor` keeps per-pin static caches (`lastFreq[]`, `lastDuty[]`) and
only touches the peripheral when a value actually changes. A steady command
performs zero peripheral writes; the timer free-runs.

**The trap this creates:** the cache mirrors the hardware. Anything that
writes the LEDC pins *without* going through `writeMotor` desynchronizes
them, after which re-sending a previously-used command is a silent no-op
(cache says "already set," hardware says 0). This exact regression occurred
when `driveStop()` still called `ledcWrite(pin, 0)` directly; it now routes
through `writeMotor(pin, 0.0f)` instead. Preserve that invariant: **all
speed-pin writes go through `writeMotor`.**

## Arbitration (`controlStep`)

Freshness: `rcAlive` = SBUS frame within `SIGNAL_TIMEOUT` (100 ms);
`cmdAlive` = host line within `CMD_TIMEOUT` (200 ms); `txOff` = frames
arriving but flag byte has `TXOFF_FLAG` (0x10) set.

| rcAlive | txOff | cmdAlive | Result |
|---|---|---|---|
| yes | no | — | **RC drives** (host ignored entirely) |
| yes | yes | yes | **Host drives** |
| yes | yes | no | Stop |
| no | — | yes | **Host drives** |
| no | — | no | Stop |

Properties worth knowing: a frame-lost blip (flag 0x04) with the TX on stays
RC. Handover in both directions is **instant, with no debounce** — a marginal
RF link flickering at the timeout edge can bounce control between sources
(OPEN_ISSUES §2). Every valid host line, including `S`, refreshes the host
heartbeat.

## Serial port allocation

| UART | Pins | Use |
|---|---|---|
| UART0 | USB via CP2102 | **Host command link** (115200 8N1). Also the flash port. Not a debug console — printing to it corrupts the command stream. Opening the port from the host asserts DTR/RTS and auto-resets the board (~300 ms). |
| UART1 | (free, GPIO 4/13 previously) | Unused. Natural home for a future debug/telemetry channel. Note UART1's *default* pins overlap the flash bus; always remap explicitly. |
| UART2 | RX = GPIO16 | SBUS in (100000 baud, 8E2, inverted). |

## Host-side design (`host/esp32_drive.py`)

`ESP32Drive` owns the port and runs a daemon sender thread that re-transmits
the **latest** target at a fixed 50 Hz. Rationale: the firmware stops after
200 ms of silence, and a path planner's tick rate is not guaranteed, so the
link's cadence is decoupled from the planner's. The planner only calls
`set_twist(v, omega)` (differential kinematics applied host-side using
`track_width`/`v_max`, ratio preserved on saturation) or `set_wheels(l, r)`.
`connect()` sleeps 0.4 s after opening the port to ride out the DTR/RTS
auto-reset; `close()` always sends `S`. Run directly, the module is keyboard
teleop (termios cbreak; requires a real TTY). `host/drive_keyboard.py` is the
same teleop for Windows (`msvcrt`), with its own inline 20 Hz send loop.
