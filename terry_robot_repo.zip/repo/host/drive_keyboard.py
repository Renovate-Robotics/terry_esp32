#!/usr/bin/env python3
"""
Keyboard drive for the SBUS+host ESP32 motor controller (Windows).

LINK: plug straight into the ESP32's USB port (the same cable used for
flashing -- CP2102 bridge, UART0). No USB-TTL adapter or GPIO wiring needed.
Point PORT (or argv[1]) at the ESP32's COM port from Device Manager.
NOTE: opening the port auto-resets the ESP32 (~300 ms dead on connect).
NOTE: the ESP32 only obeys this link when the RC transmitter is off/absent
      (see firmware arbitration); with the TX on, RC has exclusive control.

Keys:
    r / f : left  side  up / down
    u / j : right side  up / down
    space : stop (both to 0)
    x     : flip both signs (reverse)
    q/Esc : quit (sends stop)

The script streams "M <left> <right>\n" continuously at SEND_HZ so the ESP32
command watchdog (CMD_TIMEOUT) stays fed. Requires:  pip install pyserial
"""

import sys
import time
import msvcrt
import serial          # pip install pyserial

# ---- config ---------------------------------------------------------------
PORT     = "COM3"      # <-- set to your adapter's COM port (Device Manager)
BAUD     = 115200      # must match JETSON_BAUD on the ESP32
STEP     = 0.05        # change per key press
SEND_HZ  = 20          # command rate (keep well under 1000/CMD_TIMEOUT_ms)
# ---------------------------------------------------------------------------

def clamp(v):
    return max(-1.0, min(1.0, v))

def main():
    port = sys.argv[1] if len(sys.argv) > 1 else PORT
    try:
        esp = serial.Serial(port, BAUD, timeout=0)
    except serial.SerialException as e:
        print(f"Could not open {port}: {e}")
        print("Set PORT at the top of the script, or pass it as an argument:")
        print("    python drive_keyboard.py COM5")
        return

    left = 0.0
    right = 0.0
    period = 1.0 / SEND_HZ

    print(__doc__)
    print(f"Connected on {port} @ {BAUD}. Driving...\n")

    try:
        next_send = time.monotonic()
        while True:
            # --- drain all pending keystrokes ---
            while msvcrt.kbhit():
                ch = msvcrt.getch()
                if ch in (b"\x00", b"\xe0"):   # arrow/function key prefix
                    msvcrt.getch()             # consume the second byte, ignore
                    continue
                k = ch.decode(errors="ignore").lower()

                if   k == "r": left  = clamp(left  + STEP)
                elif k == "f": left  = clamp(left  - STEP)
                elif k == "u": right = clamp(right + STEP)
                elif k == "j": right = clamp(right - STEP)
                elif k == " ": left = right = 0.0
                elif k == "x": left, right = -left, -right
                elif k in ("q", "\x1b"):        # q or Esc
                    esp.write(b"S\n")
                    print("\nStopped. Bye.")
                    return

            # --- send at a steady rate to feed the watchdog ---
            now = time.monotonic()
            if now >= next_send:
                esp.write(f"M {left:.3f} {right:.3f}\n".encode())
                next_send = now + period
                print(f"\r left {left:+.2f}   right {right:+.2f}   ", end="", flush=True)

            time.sleep(0.001)

    except KeyboardInterrupt:
        pass
    finally:
        try:
            esp.write(b"S\n")   # always leave the robot stopped
            esp.close()
        except Exception:
            pass

if __name__ == "__main__":
    main()
