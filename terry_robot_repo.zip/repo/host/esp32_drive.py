#!/usr/bin/env python3
"""
esp32_drive.py -- Jetson-side driver for the SBUS+Jetson ESP32 motor controller.

The Jetson computes the path; this module owns the serial link and translates
high-level commands into the ESP32's wire protocol.

LINK
    Jetson USB  ->  ESP32 USB (CP2102, UART0).  Appears as /dev/ttyUSB0.
    115200 baud, 8N1.  One-way: we send commands, the ESP32 drives the ESCs.
    Protocol (newline-terminated ASCII):
        "M <left> <right>\n"   left,right in -1..+1   e.g.  M 0.500 -0.250
        "S\n"                  stop

WHY A BACKGROUND SENDER
    The ESP32 fails safe (stops) if it hears nothing for CMD_TIMEOUT (200 ms).
    A path planner does not tick at a guaranteed rate, so a dedicated thread
    re-sends the LATEST target at a fixed rate (default 50 Hz), independent of
    how often your planner updates it. Your planner just calls set_twist() /
    set_wheels() when it has something new; the link stays alive regardless.

USAGE
    As a library (your planner imports it):
        from esp32_drive import ESP32Drive
        with ESP32Drive("/dev/ttyUSB0") as drive:
            drive.set_twist(v=0.4, omega=0.2)   # forward + gentle left
            drive.set_wheels(0.5, -0.25)        # or raw wheel speeds
            drive.stop()

    As a keyboard teleop tool (run directly, like the Windows script):
        python3 esp32_drive.py /dev/ttyUSB0
        r/f = left up/down   u/j = right up/down   space = stop   q = quit

    Requires:  pip install pyserial
"""

import sys
import time
import threading

try:
    import serial  # pyserial
except ImportError:
    sys.exit("pyserial not found. Install it with:  pip install pyserial")


def twist_to_wheels(v, omega, track_width, v_max):
    """Differential-drive kinematics: body twist -> normalized wheel speeds.

    v          forward speed (same units as v_max), + = forward
    omega      yaw rate (rad/s), + = counter-clockwise (turn left)
    track_width distance between the left and right wheels/tracks (m)
    v_max      wheel speed that maps to full output (1.0)

    Returns (left, right) each in -1..+1, ratio preserved if either saturates.
    """
    v_left  = v - omega * track_width / 2.0
    v_right = v + omega * track_width / 2.0
    left  = v_left  / v_max
    right = v_right / v_max
    m = max(1.0, abs(left), abs(right))     # scale down together if over the rail
    return left / m, right / m


class ESP32Drive:
    """Owns the serial link and streams the latest wheel command at a fixed rate."""

    def __init__(self, port="/dev/ttyUSB0", baud=115200,
                 send_hz=50, track_width=0.30, v_max=1.0):
        self.port = port
        self.baud = baud
        self.period = 1.0 / send_hz
        self.track_width = track_width
        self.v_max = v_max

        self._ser = None
        self._left = 0.0
        self._right = 0.0
        self._lock = threading.Lock()
        self._stop_evt = threading.Event()
        self._thread = None

    # ---- connection -------------------------------------------------------
    def connect(self):
        self._ser = serial.Serial(self.port, self.baud, timeout=0, write_timeout=1)
        # Opening the port asserts DTR/RTS, which auto-resets the ESP32.
        # Wait out the reboot (~300 ms) before the ESP32 starts listening.
        time.sleep(0.4)
        self._ser.reset_input_buffer()
        self._stop_evt.clear()
        self._thread = threading.Thread(target=self._sender_loop, daemon=True)
        self._thread.start()
        return self

    def close(self):
        # Stop streaming, command a stop, then release the port.
        self._stop_evt.set()
        if self._thread:
            self._thread.join(timeout=1.0)
        if self._ser and self._ser.is_open:
            try:
                self._ser.write(b"S\n")
                self._ser.flush()
            except serial.SerialException:
                pass
            self._ser.close()

    def __enter__(self):
        return self.connect()

    def __exit__(self, exc_type, exc, tb):
        self.close()

    # ---- command API (call these from your planner) -----------------------
    def set_wheels(self, left, right):
        """Set normalized wheel speeds directly, each in -1..+1."""
        left = max(-1.0, min(1.0, float(left)))
        right = max(-1.0, min(1.0, float(right)))
        with self._lock:
            self._left, self._right = left, right

    def set_twist(self, v, omega):
        """Set a body twist; converted to wheel speeds via the robot geometry."""
        left, right = twist_to_wheels(v, omega, self.track_width, self.v_max)
        self.set_wheels(left, right)

    def stop(self):
        """Zero both wheels (the sender keeps streaming zeros -> ESP32 holds stop)."""
        self.set_wheels(0.0, 0.0)

    # ---- background streaming --------------------------------------------
    def _sender_loop(self):
        next_send = time.monotonic()
        while not self._stop_evt.is_set():
            with self._lock:
                left, right = self._left, self._right
            line = "M %.3f %.3f\n" % (left, right)
            try:
                self._ser.write(line.encode("ascii"))
            except serial.SerialException as e:
                # Link dropped (cable pulled, board reset). Report and keep trying;
                # the ESP32 will fail safe on its own after CMD_TIMEOUT.
                sys.stderr.write("serial write failed: %s\n" % e)
            next_send += self.period
            sleep = next_send - time.monotonic()
            if sleep > 0:
                time.sleep(sleep)
            else:
                next_send = time.monotonic()   # fell behind; resync the cadence


# ---------------------------------------------------------------------------
# Demo: replace the body of run_planner() with your real path/planner output.
# ---------------------------------------------------------------------------
# Keyboard teleop (Linux/Jetson). Mirrors the Windows drive_keyboard.py:
#   r / f : left  side  up / down
#   u / j : right side  up / down
#   space : stop (both to 0)
#   x     : flip both signs (reverse)
#   q/Esc : quit (sends stop)
# The ESP32Drive background thread streams the latest value, so keeping the
# ESP32 command watchdog fed is automatic -- we only push on key changes.
# ---------------------------------------------------------------------------
STEP = 0.05             # change per key press


class _RawKeyboard:
    """Non-blocking single-key reader using cbreak mode (Ctrl+C still works)."""
    def __enter__(self):
        import termios, tty
        self._termios = termios
        self._fd = sys.stdin.fileno()
        self._old = termios.tcgetattr(self._fd)
        tty.setcbreak(self._fd)          # unbuffered, no echo, but leaves SIGINT enabled
        return self

    def __exit__(self, *exc):
        self._termios.tcsetattr(self._fd, self._termios.TCSADRAIN, self._old)

    def get_key(self):
        import select
        if select.select([sys.stdin], [], [], 0)[0]:
            return sys.stdin.read(1)
        return None


def run_keyboard(drive):
    left = 0.0
    right = 0.0

    def clamp(v):
        return max(-1.0, min(1.0, v))

    print("Keyboard drive:  r/f = left up/down   u/j = right up/down")
    print("                 space = stop   x = reverse both   q/Esc = quit")

    with _RawKeyboard() as kb:
        while True:
            k = kb.get_key()
            if k is not None:
                if   k == "r": left  = clamp(left  + STEP)
                elif k == "f": left  = clamp(left  - STEP)
                elif k == "u": right = clamp(right + STEP)
                elif k == "j": right = clamp(right - STEP)
                elif k == " ": left = right = 0.0
                elif k == "x": left, right = -left, -right
                elif k in ("q", "\x1b"):          # q or Esc
                    break
                drive.set_wheels(left, right)      # sender thread streams it from here
                sys.stdout.write("\r left %+.2f   right %+.2f    " % (left, right))
                sys.stdout.flush()
            time.sleep(0.01)
    print("\nStopping.")


def main():
    port = sys.argv[1] if len(sys.argv) > 1 else "/dev/ttyUSB0"
    try:
        with ESP32Drive(port) as drive:
            run_keyboard(drive)
    except serial.SerialException as e:
        sys.exit("Could not open %s: %s\n"
                 "Pass the right port:  python3 esp32_drive.py /dev/ttyUSB0" % (port, e))
    except KeyboardInterrupt:
        print("\nInterrupted.")
    # 'with' block already sent stop and closed the port on the way out.


if __name__ == "__main__":
    main()
