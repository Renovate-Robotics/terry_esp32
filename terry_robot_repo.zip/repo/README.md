# Terry: Differential-Drive Robot Controller (ESP32 + Jetson)

Firmware and host tooling for a tracked/differential ground robot. An ESP32
sits between two command sources (an RC transmitter over SBUS, and a Jetson
or laptop over USB serial) and the motor drivers, translating high-level
speed commands into a custom PFM (pulse-frequency-modulated) speed signal
plus a direction pin per side.

```
 RC transmitter ──SBUS──► receiver ──GPIO16──►┌────────┐──GPIO25 (PFM)──► LEFT  motor driver
                                              │ ESP32  │──GPIO33 (DIR)──►
 Jetson / laptop ──USB (UART0, 115200)───────►│        │──GPIO26 (PFM)──► RIGHT motor driver
                                              └────────┘──GPIO32 (DIR)──►
```

## Repo layout

| Path | What it is |
|---|---|
| `firmware/real_esp32_terry.ino` | The ESP32 firmware (Arduino-ESP32 core 3.x). The single source of truth for robot behavior. |
| `host/esp32_drive.py` | Jetson-side driver. Importable `ESP32Drive` class for a path planner, plus keyboard teleop when run directly. Linux. |
| `host/drive_keyboard.py` | Windows keyboard teleop (bench testing from a laptop). |
| `docs/ARCHITECTURE.md` | How the firmware is structured and why; control arbitration; signal chain. |
| `docs/PROTOCOLS.md` | Exact wire formats: SBUS in, host serial in, PFM/DIR out. Logic-analyzer settings. |
| `docs/TUNING.md` | Every tunable constant, what it does, and its interaction with the others. |
| `docs/DECISION_LOG.md` | Chronological record of bugs found, fixes applied, and design decisions with rationale. **Read before "simplifying" anything.** |
| `docs/OPEN_ISSUES.md` | Unverified assumptions and known gaps. **Read before first deployment.** |

## Hardware

- **MCU:** Elegoo ESP32 dev board (classic ESP-WROOM-32, CP2102 USB-serial
  bridge). Not an S2/S3 — no native USB.
- **RC:** any SBUS receiver, inverted SBUS output wired to GPIO16, common GND.
- **Motor drivers:** two, each taking a 3.3V speed input (the PFM signal) and a
  3.3V direction input (HIGH = forward). Direction is handled entirely by the
  DIR pins; the PFM signal carries magnitude only.
- **Host:** Jetson (`/dev/ttyUSB0`, cp210x driver is stock in JetPack) or a
  Windows laptop (CP210x VCP driver, COM port in Device Manager), plugged into
  the ESP32's own USB port. No other command wiring exists anymore.

## Pin map

| GPIO | Function |
|---|---|
| 16 | SBUS in (UART2 RX, inverted, 100000 baud 8E2) |
| 25 | Left speed out (PFM, LEDC ch 0 / timer 0) |
| 26 | Right speed out (PFM, LEDC ch 2 / timer 1) |
| 33 | Left direction out (HIGH = forward) |
| 32 | Right direction out (HIGH = forward) |
| USB | Host command link (UART0 / `Serial`, 115200 8N1) — **also** the flash/debug port; there is no separate debug console (see docs/ARCHITECTURE.md) |

## Who's in control (arbitration summary)

The transmitter always wins when it is live. Autonomy (host commands) is
permitted only when SBUS frames stop arriving **or** frames arrive with the
TX-off flag set (`0x10` in the SBUS flag byte — an assumption that still needs
verification, see `docs/OPEN_ISSUES.md`). If autonomy is permitted but no host
command has arrived within 200 ms, the robot stops. If the RC link is up and
the TX is on, host commands are ignored entirely.

Practical consequence for the bench: with no transmitter powered on, the USB
link drives immediately. With the transmitter on, keyboard/planner commands
appear to do nothing — that is by design.

## Quick start

Flash `firmware/real_esp32_terry.ino` from the Arduino IDE (ESP32 core 3.x —
the LEDC API calls, e.g. `ledcAttachChannel`, are 3.x-only). Then:

```bash
# Jetson / Linux
pip install pyserial
python3 host/esp32_drive.py /dev/ttyUSB0     # keyboard teleop

# Windows
pip install pyserial
python host/drive_keyboard.py COM5
```

Keys in both: `r`/`f` left side up/down, `u`/`j` right side up/down,
`space` stop, `x` reverse both, `q`/Esc quit. Opening the port reboots the
ESP32 (CP2102 asserts DTR/RTS) — expect ~300 ms of dead air on connect, and
don't hold the Arduino Serial Monitor open at the same time.

For a planner, import the class instead of running the file:

```python
from esp32_drive import ESP32Drive
with ESP32Drive("/dev/ttyUSB0", track_width=0.30, v_max=1.0) as drive:
    drive.set_twist(v=0.4, omega=0.2)   # or drive.set_wheels(l, r)
```

A background thread re-sends the latest command at 50 Hz so the firmware
watchdog stays fed regardless of the planner's tick rate.

## The three things most likely to bite you

1. **`TXOFF_FLAG 0x10` is unverified** against the actual receiver. Standard
   SBUS failsafe is `0x08`. Verify with a logic analyzer before trusting the
   RC-off → autonomy handover. (`docs/OPEN_ISSUES.md` §1)
2. **`writeMotor` caches hardware state.** Any new code that writes the LEDC
   pins directly (bypassing `writeMotor`) will desynchronize the cache and
   silently kill the output. This already happened once. (`docs/DECISION_LOG.md`
   entries 7–8)
3. **`Serial` is the command link, not a debug console.** Adding
   `Serial.print` debugging to the loop injects garbage into the host command
   stream. Use the freed UART1 (GPIO 4/13) if a debug channel is ever needed.
